class TTSEngine:
    def speak(self, text: str):
        raise NotImplementedError
