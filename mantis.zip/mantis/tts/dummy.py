class DummyTTS:
    def speak(self, text: str):
        pass  # utile pour désactiver la voix
