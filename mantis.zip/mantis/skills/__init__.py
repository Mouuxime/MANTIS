from mantis.skills.system import SystemSkill
from mantis.skills.weather import WeatherSkill