class NLGEngine:
    def generate(self, response) -> str:
        raise NotImplementedError
